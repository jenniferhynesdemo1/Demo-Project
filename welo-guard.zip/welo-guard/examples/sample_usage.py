from src.welo_guard import WeloGuard

wg = WeloGuard()
print(wg.approve_login("alice", "tishia"))
print(wg.detect_activity("alice"))
