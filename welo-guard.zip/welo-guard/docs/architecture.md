# Architecture

The Welo Guard architecture is modular, including authentication, monitoring, and reporting layers.