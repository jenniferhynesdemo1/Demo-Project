def track_activity(user, activity):
    return f"Activity '{activity}' tracked for user {user}."
