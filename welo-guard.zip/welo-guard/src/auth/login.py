def authenticate(user, password):
    if password == "secure123":
        return f"User {user} authenticated successfully."
    return f"User {user} failed authentication."
