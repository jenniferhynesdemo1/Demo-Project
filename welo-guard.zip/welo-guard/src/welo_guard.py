class WeloGuard:
    def __init__(self, product="Welo Guard", version="1.0"):
        self.product = product
        self.version = version

    def approve_login(self, user, approver):
        return f"Login for {user} approved by {approver} via {self.product}"

    def detect_activity(self, user, activity="login_attempt"):
        return f"Monitoring {activity} from user: {user}"
