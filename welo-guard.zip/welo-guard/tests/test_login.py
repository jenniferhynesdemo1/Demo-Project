import unittest
from src.welo_guard import WeloGuard

class TestWeloGuard(unittest.TestCase):
    def test_approval(self):
        wg = WeloGuard()
        result = wg.approve_login("alice", "tishia")
        self.assertIn("approved", result)

if __name__ == "__main__":
    unittest.main()
